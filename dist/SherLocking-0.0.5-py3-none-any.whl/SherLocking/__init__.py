from SherLocking.activation import *

if __name__ == '__main__':
    print('Testing run module...')