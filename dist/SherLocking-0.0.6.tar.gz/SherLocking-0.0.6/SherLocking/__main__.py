from SherLocking.activation import activate

if __name__ == '__main__':
    activate()